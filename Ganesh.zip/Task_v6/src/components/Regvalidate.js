


export const Formvalidation = (FormData) => {

    // let Earrors_In = [];
    let Errors_obj = {};
    const Email_Pattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,6}$/;
    const Password_Pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{8,15}$/;

    if (FormData !== null || FormData !== undefined || FormData !== '') {
        var formkeys = Object.keys(FormData).length;
        if (formkeys !== 0) {

            if (FormData.UserName === "" ) {
                // // Earrors_In = [...Earrors_In, { UserName: "Your Name Required" }];
                Errors_obj = { ...Errors_obj, UserName: "Your Name Required" };
                
            }
            if (FormData.UserPassword === '') {
                // // Earrors_In = [...Earrors_In, { UserPassword: "Password Required" }];
                Errors_obj = { ...Errors_obj, UserPassword: "Password Required" };
            }
            else if (!Password_Pattern.test(FormData.UserPassword)) {
                // // Earrors_In = [...Earrors_In, { UserPassword: "Password Minimum 8 Character and Contains Atleast 1 UpperCase 1 LoswerCase 1 Number " }];
                Errors_obj = { ...Errors_obj, UserPassword: "Password Minimum 8 Character and Contains Atleast 1 UpperCase 1 LoswerCase 1 Number " };
            }
            if (FormData.Email === '') {
                // // Earrors_In = [...Earrors_In, { UserPassword: "Password Required" }];
                Errors_obj = { ...Errors_obj, Email: "Email Required" };
            }
            else if (!Email_Pattern.test(FormData.Email)) {
                // // Earrors_In = [...Earrors_In, { UserPassword: "Password Minimum 8 Character and Contains Atleast 1 UpperCase 1 LoswerCase 1 Number " }];
                Errors_obj = { ...Errors_obj, Email: " please follow the pattern example@gamil.com " };
            }

            if (FormData.UserNumber === '') {
                // // Earrors_In = [...Earrors_In, { UserNumber: "Mobile Number Required", inpname: 'mobileNumber' }];
                Errors_obj = { ...Errors_obj, UserNumber: "Mobile Number Required", inpname: 'mobileNumber' };
            }
            else if (FormData.UserNumber.length !== 10) {

                // // Earrors_In = [...Earrors_In, { UserNumber: " Please Enter 10 Digits of Mobile Number", inpname: 'mobileNumber' }];
                Errors_obj = { ...Errors_obj, UserNumber: " Please Enter 10 Digits of Mobile Number", inpname: 'mobileNumber' };
            }

            if (FormData.User_DOB === '') {

                // // Earrors_In = [...Earrors_In, { User_DOB: " Date Of Birth Required", inpname: "Dob" }];
                Errors_obj = { ...Errors_obj, dob: " Date Of Birth Required", inpname: "Dob" };

            }
        }
    }

    console.log(Errors_obj);

    return Errors_obj;

}

