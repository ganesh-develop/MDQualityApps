import React from "react";
import "./blog.css";
export const Blog = ({data}) => {

    const displayBlog = (e)=>{
      e.target.nextElementSibling.classList.toggle('show');
    }

  return (
    <div className="blog-div">
      <h4 onClick={(e)=>displayBlog(e)}> {data.services}</h4>
      <div className="post-div">
        <p>{data?.serviceDescription}</p>
      </div>
    </div>
  );
};
