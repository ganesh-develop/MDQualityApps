import React from 'react'

export const Spinner = ({ show }) => {
    return (
        <div className={`loading_box ${show}`} id='spinner'>
            <div className='inner_box'>
                <div>
                    <div className="innerchild"></div>
                </div>

            </div>
        </div>
    )
}
