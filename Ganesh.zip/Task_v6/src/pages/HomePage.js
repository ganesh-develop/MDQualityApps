import { useState, useEffect } from "react";
import { Blog } from "../components/Blog";
import "./home.css";
const HomePage = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    try {
      async function fetchdata() {
        const url =
          " https://mdqualityapps.in/API/astromaagic/development/get_services_for_website";
        let res = await fetch(url, {
          method: "GET",
        });
        if (!res.ok) throw new Error("faild to fetch");
        const data = await res.json();
        console.log(data.data);

        if (!data.error) setPosts(data?.data);
        else throw new Error("Error from Server data");
      }
      fetchdata();
    } catch (e) {
      console.log(e);
    }
  }, []);

  return (
    <div id="home-container">
      <div id="parent">
        {posts.length !== 0 ? ( posts.map((data) => <Blog key={data.serviceId} data={data} />)):"Loading Please wait ...."}
      </div>
    </div>
  );
};

export default HomePage;
