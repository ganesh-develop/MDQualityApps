import React, { useEffect, useRef, useState } from "react";
import "./formPage.css";
import { TiSocialFacebook } from "react-icons/ti";
import { FaLinkedinIn } from "react-icons/fa6";
import { FaGooglePlusG } from "react-icons/fa";
import { IoMdEye } from "react-icons/io";
import { IoMdEyeOff } from "react-icons/io";
import { Link, useNavigate } from "react-router-dom";
import { Spinner } from "../components/Spinner";
import { IoMdCheckmarkCircleOutline } from "react-icons/io";
import { FaRegCircleXmark } from "react-icons/fa6";

const LoginPage = () => {
  const [phnumber, setPhnumber] = useState("");
  const [password, setPassword] = useState("");
  const [rememberme, setRememberme] = useState(false);
  const [ispassvisible, setIspassvisible] = useState(false);
  const [loading, setLoading] = useState("");
  const phnumberRef = useRef();
  const passRef = useRef();
  const submitBtn = useRef();
  const navigate = useNavigate();
  /**
   * place the lable element border of input box
   */
  useEffect(() => {
    if (phnumber !== "") {
      phnumberRef.current.nextElementSibling.classList.add("focus-label");
    } else {
      phnumberRef.current.nextElementSibling.classList.remove("focus-label");
    }

    if (password !== "") {
      passRef.current.nextElementSibling.classList.add("focus-label");
    } else {
      passRef.current.nextElementSibling.classList.remove("focus-label");
    }

    if (phnumber.trim() === "" || password.trim() === "") {
      submitBtn.current.classList.add("submit-invalid");
      submitBtn.current.disabled = true;
      return;
    }
    console.log("workkk");
    submitBtn.current.classList.remove("submit-invalid");
    submitBtn.current.disabled = false;
  }, [phnumber, password]);

  /**
   * handled Password vosible or not
   */
  const TogglePassVisible = () => {
    try {
      const spanEle = document.getElementById("passvisible-btn");
      spanEle.classList.toggle("show");
      const classname = spanEle.classList;

      if (classname.contains("show")) {
        passRef.current.type = "text";
        setIspassvisible(true);
      } else {
        passRef.current.type = "password";
        setIspassvisible(false);
      }
    } catch (e) {
      console.log(e.stack);
    }
  };

  /*
   * handle form submit event
   */
  const HandleSubmit = async (e) => {
    e.preventDefault();
    /*
     * step 1 : validate user inputs..
     * step 2 : if it has no errors the rise  API request
     * step 3 : display the response
     *  */
    submitBtn.current.style.display = "none";
    setLoading("show");

    const formdata = new FormData();
    formdata.append("mobile", phnumber);
    formdata.append("userPassword", password);

    try {
      let url = "https://mdqualityapps.in/API/resume/development/user_login";

      let res = await fetch(url, {
        method: "POST",
        body: formdata,
      });
      if (!res.ok) throw new Error("Login Faild");
      let data = await res.json();
      console.log(data);

      let isCorrect = !data.error;
      setLoading("");

      if (isCorrect) {
        document.getElementById("successSymbol").style.display = "block";
      } else {
        document.getElementById("faildSymbol").style.display = "block";
      }

      setTimeout(() => {
        disableanimations();
        alert(data.message);
        if (isCorrect) {
          navigate("/Home");
        }
        
      }, 2000);
    } catch (e) {
      disableanimations();
      console.log(e.stack);
    }
  };

  const disableanimations = () => {
    document.getElementById("successSymbol").style.display = "none";
    document.getElementById("faildSymbol").style.display = "none";

    submitBtn.current.style.display = "block";
  };

  console.log("Login Page...");
  return (
    <div id="lgcontainer">
      <div className="lg-boxes lgbox-1 bg-white">
        <p className="logo-txt">
          <span className="fw-bold">MDQuality</span> App Solution
        </p>

        <div className=" mb-3 content-box">
          <div className="full-flex">
            <h2 className="fw-bold form-type-txt">Sign in to Account</h2>
            {/*span used to underline*/}
            <span className="small-underline lft  mb-2"></span>

            <div className="d-flex gap-3 mt-3 mb-3">
              <div className="circledivs ">
                <TiSocialFacebook />
              </div>
              <div className="circledivs " style={{ fontSize: "15px" }}>
                <FaLinkedinIn />
              </div>
              <div className="circledivs">
                <FaGooglePlusG />
              </div>
            </div>
          </div>
          <div className="full-flex">
            <a className="mb-3 a-navigate" href="/hoo">
              or use your phnumber account
            </a>
            <form onSubmit={(e) => HandleSubmit(e)} className="lr-frm ">
              <div className="frm-grp">
                <input
                  id="phnumber"
                  autoComplete="off"
                  ref={phnumberRef}
                  type="tel"
                  pattern="[0-9]{10}"
                  name="phnumber"
                  className="w-100 inputboxes"
                  value={phnumber}
                  onChange={(e) => setPhnumber(e.target.value.trim())}
                />
                <label htmlFor="phnumber" className="movable-label">
                  Phone Number
                </label>
              </div>
              <div className="frm-grp pass-parent ">
                <input
                  id="password"
                  autoComplete="off"
                  ref={passRef}
                  type="password"
                  name="password"
                  className="w-100 inputboxes"
                  value={password}
                  onChange={(e) => setPassword(e.target.value.trim())}
                />
                <label htmlFor="password" className="movable-label">
                  Password
                </label>
                <span
                  id="passvisible-btn"
                  onClick={() => TogglePassVisible()}
                  className="passvisible-btn"
                >
                  {" "}
                  {ispassvisible ? <IoMdEye /> : <IoMdEyeOff />}
                </span>
              </div>

              <div
                className=" inp-par d-flex  align-items-center justify-content-between w-100 "
                style={{ fontSize: "13px" }}
              >
                <div className="d-flex gap-2">
                  {/* Square Input Box */}
                  <div className="form-check ">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value=""
                      id="defaultCheck1"
                      onChange={(e) => setRememberme(e.target.checked)}
                    />
                  </div>
                  <label
                    htmlFor="defaultCheck1"
                    className="fw-bold cursor-pointer "
                  >
                    Remember me
                  </label>
                </div>
                <a
                  className="fw-bold a-navigate reset-pass "
                  href="/ResetPassword"
                >
                  Forgot Password?
                </a>
              </div>
              <div className="submit-parent mt-2">
                <input
                  ref={submitBtn}
                  type="submit"
                  value={"Sign in"}
                  disabled={true}
                  className="  buttonscol  submit-invalid"
                  style={{}}
                />
                <Spinner show={loading}></Spinner>

                <IoMdCheckmarkCircleOutline
                  className="status-symbol"
                  id="successSymbol"
                />
                <FaRegCircleXmark className="status-symbol" id="faildSymbol" />
              </div>
            </form>
          </div>
        </div>

        <div
          className="ms-0 p-0 m-0 mb-1 position-absolute bottom-0 w-fitContent"
          style={{
            fontSize: "12px",
            width: "fit-content",
            height: "25px",
            padding: "0 10px ",
            overflow: "hidden",
          }}
        >
          <ul
            className=" ms-0 m-0 p-0 d-flex h-100 "
            style={{
              color: "rgb(88, 88, 88)",
              width: "100%",
            }}
          >
            <li className="list-unstyled">
              <a className="a-navigate tc" href="/aboud/privacypolicy">
                Privacy Policy
              </a>
            </li>

            <li className="ms-4 ">
              <a className="a-navigate tc" href="/about/termsandconditions">
                Terms & Conditions
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="lg-boxes lgbox-2">
        <div className="lg-2-contentbox">
          <h2 className=" text-white fw-bold ">Hello, Friend!</h2>
          <span className="small-underline  mb-2"></span>
          <span
            style={{
              fontWeight: "400",
              fontSize: "13px",
              textAlign: "center",
              color: "white",
              opacity: "0.9",
            }}
          >
            Fill Up Personal information and start journey with us
          </span>
        </div>
        <div className="mt-3 button-atag">
          <Link className="text-light fw-bold btn-atag " to="/Register">
            Sign Up
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
