import React, { useEffect, useRef, useState } from "react";
import "./formPage.css";
import { TiSocialFacebook } from "react-icons/ti";
import { FaLinkedinIn } from "react-icons/fa6";
import { FaGooglePlusG } from "react-icons/fa";
import { IoMdEye } from "react-icons/io";
import { IoMdEyeOff } from "react-icons/io";
import { Link, useNavigate } from "react-router-dom";
import { Formvalidation } from "../components/Regvalidate.js";
import { Spinner } from "../components/Spinner";
import { IoMdCheckmarkCircleOutline } from "react-icons/io";
import { FaRegCircleXmark } from "react-icons/fa6";



const RegisterPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [phnumber, setPhnumber] = useState("");
  const [email, setEmail] = useState("");
  const [dob, setDob] = useState("2000-01-30");
  // const [gender, setGender] = useState("");
  const [rememberme, setRememberme] = useState(false);
  const [ispassvisible, setIspassvisible] = useState(false);
  const [issubmited, setIssubmited] = useState(false);
  const [loading, setLoading] = useState("");
  const usernameRef = useRef();
  let passRef = useRef();
  const phnumberRef = useRef();
  const submitBtn = useRef();
  const emailRef = useRef();
  const [userErros, setUserErrors] = useState({});
  const navigate = useNavigate();
  /**
   *  adding focus in ,out Effect
   * place the lable element in border of the input box
   */
  useEffect(() => {
    if (username !== "")
      usernameRef.current.nextElementSibling.classList.add("focus-label");
    else usernameRef.current.nextElementSibling.classList.remove("focus-label");

    if (password !== "")
      passRef.current.nextElementSibling.classList.add("focus-label");
    else passRef.current.nextElementSibling.classList.remove("focus-label");

    if (phnumber !== "")
      phnumberRef.current.nextElementSibling.classList.add("focus-label");
    else phnumberRef.current.nextElementSibling.classList.remove("focus-label");

    if (email !== "")
      emailRef.current.nextElementSibling.classList.add("focus-label");
    else emailRef.current.nextElementSibling.classList.remove("focus-label");
  }, [username, password, phnumber, email]);

  /**
   * handled Password vosible or not
   */

  const TogglePassVisible = () => {
    console.log("pass toggle");
    try {
      const spanEle = document.getElementById("passvisible-btn");
      spanEle.classList.toggle("show");
      const classname = spanEle.classList;

      if (classname.contains("show")) {
        passRef.current.type = "text";
        setIspassvisible(true);
      } else {
        passRef.current.type = "password";
        setIspassvisible(false);
      }
    } catch (e) {
      console.log(e.stack);
    }
  };
  /**
   * Enable the submit button when user fiel*/

  useEffect(() => {
    try {
      if (
        username.trim() === "" ||
        password.trim() === "" ||
        phnumber.trim() === "" ||
        dob.trim() === ""
      ) {
        submitBtn.current.classList.add("submit-invalid");
        submitBtn.current.disabled = true;
      } else {
        submitBtn.current.classList.remove("submit-invalid");
        submitBtn.current.disabled = false;
      }
    } catch (e) {
      console.log(e.stack);
    }
  }, [username, password, phnumber, dob]);

  /*
   * handle form submit event
   */
  const HandleSubmit = async (e) => {
    e.preventDefault();
    console.log("form submited");
    submitBtn.current.style.display = "none";
    setLoading("show");
    setIssubmited(true);
    /*
     * step 1 : validate user inputs..
     * step 2 : if it has no errors the rise  API request
     * step 3 : display the response
     *  */

    const User_details = {
      UserName: username,
      UserPassword: password,
      UserNumber: phnumber,
      User_DOB: dob,
      Email: email,
    };

    /**
     * Sample Error validation in frontent
     * */
    try {
      setUserErrors(Formvalidation(User_details));
    } catch (e) {
      document.getElementById("faildSymbol").style.display = "block";
      setLoading("");
      console.log(e.stack);
      console.log("error from Error Validation");
      disableanimations();
    }
  };

  const regfetch = async () => {
    console.log("fetching.........................");
    setIssubmited(false);
    // for fist time state manage
    try {
      const errorskeys = Object.keys(userErros).length;
      console.log("errorskeys length : " + errorskeys);
      if (errorskeys === 0) {
        /*
         * Fetch Api Call
         */
        let formdata = new FormData();
        formdata.append("userName", username);
        formdata.append("userPassword", password);
        formdata.append("mobile", phnumber);
        formdata.append("email", email);
        formdata.append("yop", dob);

        let data = {};
        const url = "https://mdqualityapps.in/API/resume/development/add_user";

        const res = await fetch(url, {
          method: "POST",
          body: formdata,
        });
        if (!res.ok) throw new Error("faild to Fetch");
        data = await res.json();
        console.log(data);

        if (!data?.error) {
          console.log(".................................");

          document.getElementById("successSymbol").style.display = "block";
          setLoading("");
        } else {
          document.getElementById("faildSymbol").style.display = "block";
          setLoading("");
        }

        setTimeout(() => {
          disableanimations();
          alert(data.message);
          if (!data.error) {
            navigate("/Home");
          }
        }, 2000);
      } else {
        document.getElementById("faildSymbol").style.display = "block";
        setLoading("");
        disableanimations();
      }
    } catch (e) {
      document.getElementById("faildSymbol").style.display = "block";
      setLoading("");
      console.log(e.stack);
      console.log("error from Error Validation");
    } finally {
      setTimeout(() => disableanimations(), 2000);
    }
  };

  useEffect(() => {
    console.log("len : " + [].length);
    if (issubmited) {
      regfetch();
    } else {
      console.log("No form submited");
      disableanimations();
    }
  }, [userErros]);

  const disableanimations = () => {
    document.getElementById("successSymbol").style.display = "none";
    document.getElementById("faildSymbol").style.display = "none";
    submitBtn.current.style.display = "block";
  };
  console.log("register...");
  console.log(userErros);

  return (
    <div id="lgcontainer">
      <div className="lg-boxes lgbox-1 bg-white ">
        <p className="logo-txt">
          <span className="fw-bold">MDQuality</span> App Solution
        </p>

        <div className=" mb-3 content-box">
          <div className="full-flex">
            <h2 className="fw-bold form-type-txt">Sign up to Account</h2>
            {/*span used to underline*/}
            <span className="small-underline lft  mb-1"></span>

            <div className="d-flex gap-3 mt-2 mb-3">
              <div className="circledivs ">
                <TiSocialFacebook />
              </div>
              <div className="circledivs " style={{ fontSize: "15px" }}>
                <FaLinkedinIn />
              </div>
              <div className="circledivs">
                <FaGooglePlusG />
              </div>
            </div>
          </div>
          <div className="full-flex">
            {/* <a className='mb-3 a-navigate' href="/hoo">or use your username account</a> */}

            <form onSubmit={(e) => HandleSubmit(e)} className="lr-frm ">
              {/* username */}
              <div className="frm-grp">
                <input
                  id="username"
                  autoComplete="off"
                  ref={usernameRef}
                  type="text"
                  name="username"
                  className="w-100 inputboxes"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.trim())}
                />
                <label
                  htmlFor="username"
                  className="movable-label"
                  id="usernamelbl"
                >
                  Your Name
                </label>
              </div>

              {userErros.UserName && <p>{userErros?.UserName}</p>}
              {/* password */}

              <div className="frm-grp pass-parent ">
                <input
                  id="password"
                  autoComplete="off"
                  ref={passRef}
                  type="password"
                  name="password"
                  className="w-100 inputboxes"
                  value={password}
                  onChange={(e) => setPassword(e.target.value.trim())}
                />
                <label
                  htmlFor="password"
                  className="movable-label"
                  id="passlbl"
                >
                  Password
                </label>
                <span
                  id="passvisible-btn"
                  onClick={() => TogglePassVisible()}
                  className="passvisible-btn"
                >
                  {" "}
                  {ispassvisible ? <IoMdEye /> : <IoMdEyeOff />}
                </span>
              </div>
              {userErros.UserPassword && <p>{userErros.UserPassword}</p>}

              {/* number */}
              <div className="frm-grp">
                <input
                  id="phnumber"
                  autoComplete="off"
                  ref={phnumberRef}
                  type="tel"
                  pattern="[0-9]{10}"
                  name="phnumber"
                  className="w-100 inputboxes"
                  value={phnumber}
                  onChange={(e) => setPhnumber(e.target.value.trim())}
                />
                <label
                  htmlFor="phnumber"
                  className="movable-label"
                  id="numberlbl"
                >
                  Number
                </label>
              </div>

              {userErros?.UserNumber && <p>{userErros.UserNumber}</p>}
              {/* Gmail div */}
              <div className="frm-grp">
                <input
                  id="email"
                  autoComplete="off"
                  ref={emailRef}
                  type="email"
                  name="email"
                  className="w-100 inputboxes"
                  value={email}
                  onChange={(e) => setEmail(e.target.value.trim())}
                />
                <label htmlFor="email" className="movable-label" id="emaillbl">
                  Email
                </label>
              </div>

              {userErros.Email && <p>{userErros?.Email}</p>}

              {/* date of birth */}
              <div className="frm-grp">
                <input
                  placeholder=" hi ima"
                  id="dob"
                  autoComplete="off"
                  type="date"
                  name="dob"
                  className="w-100 inputboxes"
                  value={dob}
                  onChange={(e) => setDob(e.target.value.trim())}
                />
                {userErros.dob && <p>{userErros?.dob}</p>}
              </div>
              {/* gender */}
              {/* <div
                className="inp-par d-flex  align-items-center justify-content-between w-100"
                style={{
                  fontSize: "12px",
                  fontWeight: "bold",
                }}
              >
                <div className=" d-flex  align-items-center justify-content-between gap-2 fw-700">
                  <input
                    id="male"
                    autoComplete="off"
                    type="radio"
                    name="gender"
                    className="w-100 inputboxes"
                    value={"male"}
                    onChange={(e) => setGender(e.target.value.trim())}
                  />
                  <label htmlFor="male" className="">
                    Male
                  </label>
                </div>

                <div className=" d-flex  align-items-center justify-content-between gap-2">
                  <input
                    id="female"
                    autoComplete="off"
                    type="radio"
                    name="gender"
                    className="w-100 inputboxes"
                    value={"male"}
                    onChange={(e) => setGender(e.target.value.trim())}
                  />
                  <label htmlFor="female" className="">
                    Female
                  </label>
                </div>

                <div className=" d-flex  align-items-center justify-content-between gap-2">
                  <input
                    id="other"
                    autoComplete="off"
                    type="radio"
                    name="gender"
                    className="w-100 inputboxes"
                    value={"other"}
                    onChange={(e) => setGender(e.target.value.trim())}
                  />
                  <label htmlFor="other" className="">
                    Other
                  </label>
                </div>
              </div>
              {userErros.Gender && <p>{userErros?.Gender}</p>} */}

              {/* Remember me And Forgot Password */}

              <div
                className="inp-par d-flex  align-items-center justify-content-between w-100 "
                style={{ fontSize: "13px" }}
              >
                <div className="d-flex gap-2">
                  {/* Square Input Box */}
                  <div className="form-check ">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value=""
                      id="defaultCheck1"
                      onChange={(e) => setRememberme(e.target.checked)}
                    />
                  </div>
                  <label
                    htmlFor="defaultCheck1"
                    className="fw-bold cursor-pointer "
                  >
                    Remember me
                  </label>
                </div>
                <a
                  className="fw-bold a-navigate reset-pass "
                  href="/ResetPassword"
                >
                  Forgot Password?
                </a>
              </div>

              <div className="submit-parent mt-3">
                <input
                  ref={submitBtn}
                  type="submit"
                  value={"Sign in"}
                  disabled={true}
                  className=" buttonscol  submit-invalid"
                  style={{}}
                />

                <Spinner show={loading}></Spinner>

                <IoMdCheckmarkCircleOutline
                  className="status-symbol"
                  id="successSymbol"
                />
                <FaRegCircleXmark className="status-symbol" id="faildSymbol" />
              </div>
            </form>
          </div>
        </div>

        <div
          className="ms-0 p-0 m-0 mb-1 position-absolute bottom-0 w-fitContent"
          style={{
            fontSize: "12px",
            width: "fit-content",
            height: "25px",
            padding: "0 10px ",
            overflow: "hidden",
          }}
        >
          <ul
            className=" ms-0 m-0 p-0 d-flex h-100 "
            style={{
              color: "rgb(88, 88, 88)",
              width: "100%",
            }}
          >
            <li className="list-unstyled">
              <a className="a-navigate tc" href="/aboud/privacypolicy">
                Privacy Policy
              </a>
            </li>

            <li className="ms-4 ">
              <a className="a-navigate tc" href="/about/termsandconditions">
                Terms & Conditions
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="lg-boxes lgbox-2 ">
        <div className="lg-2-contentbox">
          <h2 className=" text-white fw-bold ">Hello, Friend!</h2>
          <span className="small-underline  mb-2"></span>
          <span
            style={{
              fontWeight: "400",
              fontSize: "13px",
              textAlign: "center",
              color: "white",
              opacity: "0.9",
            }}
          >
            Fill Up Personal information and start journey with us
          </span>
        </div>
        <div className="mt-3 button-atag">
          <Link className="text-light fw-bold btn-atag " to="/Login">
            Sign in
          </Link>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
